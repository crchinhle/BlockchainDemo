# Kết quả E01
Lượt hợp lệ: Hybrid 135/135; trực tiếp trên chuỗi 45/45; sự kiện thu hồi 90/90.

Số dưới đây là trung vị [nhỏ nhất; lớn nhất] trên các seed độc lập. Thông lượng dùng thời gian đo thực gồm drain. Không gộp smoke hoặc dữ liệu cũ.

## HTTP ở tải đặt 100 thao tác/giây

| Chiến lược | Cache (ms) | Token (ms) | Lượt | Cho phép/s | Tỷ lệ cho phép trên lịch |
|---|---:|---:|---:|---|---|
| DIRECT_ONCHAIN | không áp dụng | 1000 | 5 | 45.365 [43.270; 45.873] | 0.505 [0.488; 0.509] |
| DIRECT_ONCHAIN | không áp dụng | 2000 | 5 | 44.811 [43.749; 45.916] | 0.504 [0.479; 0.510] |
| DIRECT_ONCHAIN | không áp dụng | 800 | 5 | 44.995 [43.198; 45.355] | 0.497 [0.481; 0.502] |
| HYBRID | 1000 | 1000 | 5 | 32.859 [26.890; 34.867] | 0.349 [0.285; 0.373] |
| HYBRID | 1000 | 2000 | 5 | 32.471 [25.615; 36.204] | 0.350 [0.281; 0.388] |
| HYBRID | 1000 | 800 | 5 | 30.952 [25.725; 35.974] | 0.334 [0.292; 0.385] |
| HYBRID | 2000 | 1000 | 5 | 37.427 [35.498; 41.522] | 0.404 [0.370; 0.436] |
| HYBRID | 2000 | 2000 | 5 | 39.283 [37.394; 40.179] | 0.418 [0.398; 0.424] |
| HYBRID | 2000 | 800 | 5 | 35.851 [34.352; 38.927] | 0.374 [0.361; 0.417] |
| HYBRID | 5000 | 1000 | 5 | 43.868 [42.118; 46.312] | 0.483 [0.457; 0.490] |
| HYBRID | 5000 | 2000 | 5 | 45.290 [44.111; 45.882] | 0.488 [0.469; 0.497] |
| HYBRID | 5000 | 800 | 5 | 41.068 [35.782; 41.975] | 0.433 [0.395; 0.451] |

## Thu hồi với cùng cặp cache/token

Phép này dùng bộ dò riêng, không chạy dưới tải HTTP nói trên. Mỗi dòng có tối đa 5 sự kiện độc lập. Hai cohort thuộc cùng sự kiện không phải hai lần lặp độc lập. Thời gian tính từ xác nhận giao dịch. Không thấy allow sau xác nhận không được thay bằng thời điểm allow cuối bằng 0.

| Cache/token (ms) | Sự kiện | Nhóm | Lượt | Allow cuối (ms), chỉ các lượt có allow | Không thấy allow | Còn allow ở cuối |
|---|---|---|---:|---|---:|---:|
| 1000/1000 | delivered | old-token | 5 | 81.000 [30.000; 132.000], n=2 | 3 | 0 |
| 1000/1000 | delivered | refresh | 5 | 58.000 [58.000; 58.000], n=1 | 4 | 0 |
| 1000/1000 | dropped | old-token | 5 | 877.000 [773.000; 885.000], n=5 | 0 | 0 |
| 1000/1000 | dropped | refresh | 5 | 914.000 [839.000; 923.000], n=5 | 0 | 0 |
| 1000/2000 | delivered | old-token | 5 | 21.000 [20.000; 28.000], n=3 | 2 | 0 |
| 1000/2000 | delivered | refresh | 5 | 60.000 [57.000; 66.000], n=3 | 2 | 0 |
| 1000/2000 | dropped | old-token | 5 | 807.000 [765.000; 883.000], n=5 | 0 | 0 |
| 1000/2000 | dropped | refresh | 5 | 908.000 [838.000; 917.000], n=5 | 0 | 0 |
| 1000/800 | delivered | old-token | 5 | 21.000 [20.000; 21.000], n=3 | 2 | 0 |
| 1000/800 | delivered | refresh | 5 | 56.000 [55.000; 58.000], n=3 | 2 | 0 |
| 1000/800 | dropped | old-token | 5 | 666.000 [662.000; 674.000], n=5 | 0 | 0 |
| 1000/800 | dropped | refresh | 5 | 912.000 [907.000; 919.000], n=5 | 0 | 0 |
| 2000/1000 | delivered | old-token | 5 | 22.000 [20.000; 129.000], n=3 | 2 | 0 |
| 2000/1000 | delivered | refresh | 5 | 63.500 [56.000; 71.000], n=2 | 3 | 0 |
| 2000/1000 | dropped | old-token | 5 | 878.000 [875.000; 880.000], n=5 | 0 | 0 |
| 2000/1000 | dropped | refresh | 5 | 1884.000 [1868.000; 1916.000], n=5 | 0 | 0 |
| 2000/2000 | delivered | old-token | 5 | 125.000 [125.000; 125.000], n=1 | 4 | 0 |
| 2000/2000 | delivered | refresh | 5 | 65.000 [65.000; 65.000], n=1 | 4 | 0 |
| 2000/2000 | dropped | old-token | 5 | 1855.000 [1854.000; 1859.000], n=5 | 0 | 0 |
| 2000/2000 | dropped | refresh | 5 | 1892.000 [1887.000; 1902.000], n=5 | 0 | 0 |
| 2000/800 | delivered | old-token | 5 | 22.000 [20.000; 24.000], n=2 | 3 | 0 |
| 2000/800 | delivered | refresh | 5 | 55.000 [55.000; 55.000], n=1 | 4 | 0 |
| 2000/800 | dropped | old-token | 5 | 669.000 [662.000; 675.000], n=5 | 0 | 0 |
| 2000/800 | dropped | refresh | 5 | 1892.000 [1881.000; 1923.000], n=5 | 0 | 0 |
| 5000/1000 | delivered | old-token | 5 | 20.500 [20.000; 21.000], n=2 | 3 | 0 |
| 5000/1000 | delivered | refresh | 5 | 60.000 [60.000; 60.000], n=2 | 3 | 0 |
| 5000/1000 | dropped | old-token | 5 | 882.000 [878.000; 890.000], n=5 | 0 | 0 |
| 5000/1000 | dropped | refresh | 5 | 4828.000 [2112.000; 4905.000], n=5 | 0 | 0 |
| 5000/2000 | delivered | old-token | 5 | 75.500 [20.000; 131.000], n=4 | 1 | 0 |
| 5000/2000 | delivered | refresh | 5 | 56.000 [55.000; 58.000], n=4 | 1 | 0 |
| 5000/2000 | dropped | old-token | 5 | 1853.000 [1746.000; 1855.000], n=5 | 0 | 0 |
| 5000/2000 | dropped | refresh | 5 | 4895.000 [2107.000; 4914.000], n=5 | 0 | 0 |
| 5000/800 | delivered | old-token | 5 | 25.500 [19.000; 141.000], n=4 | 1 | 0 |
| 5000/800 | delivered | refresh | 5 | 59.000 [54.000; 66.000], n=3 | 2 | 0 |
| 5000/800 | dropped | old-token | 5 | 662.000 [661.000; 665.000], n=5 | 0 | 0 |
| 5000/800 | dropped | refresh | 5 | 4893.000 [2104.000; 4906.000], n=5 | 0 | 0 |

## Đọc đánh đổi và giới hạn

tables/tradeoffs-paired.csv giữ chênh lệch theo cùng seed so với cache 1 giây/token 0,8 giây; tradeoffs-summary.csv giữ trung vị/min/max của các chênh lệch. Ô trống về allow cuối là không đủ quan sát để lấy hiệu, không phải hiệu bằng 0. paired-summary.csv mở rộng các cặp cấu hình HTTP còn lại. Không chọn một cấu hình tốt nhất cho mọi điều kiện.

Mốc đồng bộ event/poll được ghi trực tiếp. Với đường đọc snapshot trong yêu cầu, thời điểm phát hiện và cập nhật phiên bản chỉ xác định trong khoảng từ bắt đầu đọc đến phản hồi LICENSE_INACTIVE; các cột *_upper_ms là cận trên quan sát, không phải mốc chính xác. next_deny_stage tách từ chối cấp token khỏi từ chối truy cập thực.

Một máy local, một đợt chạy, năm seed; không chứng minh cận bảo đảm hoặc suy rộng mainnet. Không cách ly CPU toàn máy. Đối chứng không cache nhưng giữ giới hạn tuổi snapshot 5 giây theo quy tắc hiện có. Thông lượng là toàn luồng cấp-và-xác minh HTTP, không phải riêng một endpoint. RPC chỉ bao phủ phần đường yêu cầu có telemetry.

## Kiểm tra chất lượng
Số kiểm tra: 918; chưa đạt: 0.
Lượt lỗi và liên kết chạy lại: tables/attempt-inventory.csv. Tất cả thiếu dữ liệu/timeout/lỗi kỹ thuật được giữ, không điền số đo giả.
